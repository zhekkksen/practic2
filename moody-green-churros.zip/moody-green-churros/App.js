import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  Button,
  Modal
} from 'react-native';

export default function App() {

  const artworks = [
    {
      title: "Starry Night",
      author: "Vincent van Gogh",
      year: 1889,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/e/ea/The_Starry_Night.jpg",
      description: "One of the most recognized paintings in Western art."
    },
    {
      title: "Mona Lisa",
      author: "Leonardo da Vinci",
      year: 1503,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/6/6a/Mona_Lisa.jpg",
      description: "A portrait painting by the Italian Renaissance artist."
    },
    {
      title: "The Scream",
      author: "Edvard Munch",
      year: 1893,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/f/f4/The_Scream.jpg",
      description: "Expressionist painting showing a figure with an agonized expression."
    },
    {
      title: "Girl with a Pearl Earring",
      author: "Johannes Vermeer",
      year: 1665,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/d/d7/Meisje_met_de_parel.jpg",
      description: "Sometimes referred to as the 'Dutch Mona Lisa'."
    },
    {
      title: "The Persistence of Memory",
      author: "Salvador Dalí",
      year: 1931,
      imageUrl: "https://upload.wikimedia.org/wikipedia/en/d/dd/The_Persistence_of_Memory.jpg",
      description: "Famous for its melting clocks."
    },
    {
      title: "The Kiss",
      author: "Gustav Klimt",
      year: 1908,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/7/7d/Gustav_Klimt_016.jpg",
      description: "An iconic symbol of love."
    },
    {
      title: "American Gothic",
      author: "Grant Wood",
      year: 1930,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/7/74/Grant_Wood_-_American_Gothic_-_Google_Art_Project.jpg",
      description: "One of the most familiar images in American art."
    },
    {
      title: "Guernica",
      author: "Pablo Picasso",
      year: 1937,
      imageUrl: "https://upload.wikimedia.org/wikipedia/en/7/74/PicassoGuernica.jpg",
      description: "A powerful political statement."
    },
    {
      title: "The Birth of Venus",
      author: "Sandro Botticelli",
      year: 1486,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/1/1c/Birth_of_Venus_Botticelli.jpg",
      description: "Depicts the goddess Venus emerging from the sea."
    },
    {
      title: "The Night Watch",
      author: "Rembrandt",
      year: 1642,
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/2/28/The_Nightwatch_by_Rembrandt.jpg",
      description: "One of the most famous Dutch Golden Age paintings."
    }
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    console.log("Current artwork:", artworks[currentIndex].title);
  }, [currentIndex]);

  const nextItem = () => {
    if (currentIndex < artworks.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevItem = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const currentItem = artworks[currentIndex];

  return (
    <View style={styles.container}>

      <TouchableOpacity onLongPress={() => setModalVisible(true)}>
        <Image
          source={{ uri: currentItem.imageUrl }}
          style={styles.image}
        />
      </TouchableOpacity>

      <Text style={styles.title}>{currentItem.title}</Text>
      <Text>{currentItem.author}</Text>
      <Text>{currentItem.year}</Text>

      <View style={styles.buttons}>
        <Button
          title="Предыдущий"
          onPress={prevItem}
          disabled={currentIndex === 0}
        />
        <Button
          title="Следующий"
          onPress={nextItem}
          disabled={currentIndex === artworks.length - 1}
        />
      </View>

      <Modal visible={modalVisible} transparent={true} animationType="slide">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={{ fontSize: 18, marginBottom: 10 }}>
              {currentItem.description}
            </Text>
            <Button title="Закрыть" onPress={() => setModalVisible(false)} />
          </View>
        </View>
      </Modal>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5'
  },
  image: {
    width: 300,
    height: 300,
    borderRadius: 10,
    marginBottom: 20
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold'
  },
  buttons: {
    flexDirection: 'row',
    marginTop: 20,
    gap: 20
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)'
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    width: 300,
    alignItems: 'center'
  }
});
